package com.opengles.android.createopengles20;

import android.content.Context;
import android.opengl.GLSurfaceView;

/**
 * Created by fdsfds on 12/7/2016.
 */

public class MyGLSurfaceView extends GLSurfaceView {
    private final MyGLRenderer mRenderer;

    public MyGLSurfaceView(Context context){
        super(context);

        // Khai bao su dung OpenGL ES 2.0
        setEGLContextClientVersion(2);

        mRenderer = new MyGLRenderer();

        // Cai dat Renderer dung de ve GLSurfaceView
        setRenderer(mRenderer);
    }
}
